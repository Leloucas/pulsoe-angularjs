angular.module('pulsoe').animation('.slide-animation', slideAnimation);

function slideAnimation() {
    
});